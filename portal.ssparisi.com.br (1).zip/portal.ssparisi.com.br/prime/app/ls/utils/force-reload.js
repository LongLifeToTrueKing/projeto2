forceReload = () => {
    const form = document.createElement('form');
    form.method = "POST";
    form.action = location.href;
    document.body.appendChild(form);
    form.submit();
}
window.utils = Object.assign(window.utils || {}, {
    forceReload
})